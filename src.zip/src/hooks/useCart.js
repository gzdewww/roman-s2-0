import { useState } from "react";

export const useCart = () => {
  const [cart, setCart] = useState([
    { id: 1, quantity: 1 },
    { id: 2, quantity: 3 },
  ]);

  const addToCart = (dish) => {
    if (cart.includes(dish)) {
      setCart((prevCart) =>
        prevCart.map((item) =>
          item.id === dish.id ? { ...item, quantity: item.quantity + 1 } : item
        )
      );
      return;
    }
    setCart((prevCart) => [...prevCart, { id: dish.id, quantity: 1 }]);
  };

  const removeFromCart = (dish) => {
    if (dish.quantity === 1) {
      setCart((prevCart) => prevCart.filter((item) => item.id !== dish.id));
      return;
    }
    setCart((prevCart) =>
      prevCart.map((item) =>
        item.id === dish.id ? { ...item, quantity: item.quantity - 1 } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  return { cart, addToCart, removeFromCart, clearCart };
};
