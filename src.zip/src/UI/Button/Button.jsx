import "./Button.scss";

export default function Button({ children, onClick, className }) {
  return (
    <button
      onClick={onClick}
      className={`custom-button ${className ? className : ""}`}
    >
      {children}
    </button>
  );
}
