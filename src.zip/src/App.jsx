import Header from "./components/Header/Header";
import QuantityControl from "./components/QuantityControl/QuantityControl";
import { useCart } from "./hooks/useCart";
import "./App.scss";

function App() {
  const menu = [
    {
      id: 1,
      name: 'Пицца "вкусни"',
      price: 920,
      calories: 300,
      weight: 1200,
      description:
        "vkusnaya pitsa vkusnaya pitsa vkusnaya pitsa vkusnaya pitsa vkusnaya pitsa vkusnaya pitsa",
      photo: "images/pizza.jpg",
    },
    {
      id: 2,
      name: 'Ролл фирменный "Роман"',
      price: 321,
      calories: 200,
      weight: 900,
      description:
        "rolli rolli rolli rolli rolli rolli rolli rolli rolli rolli rolli rolli rolli rolli",
      photo: "images/rolli.jpg",
    },
  ];

  const { cart, addToCart, removeFromCart, clearCart } = useCart();

  addToCart(menu[0]);

  return (
    <>
      <Header
        menu={menu}
        cart={cart}
        addToCart={addToCart}
        removeFromCart={removeFromCart}
        clearCart={clearCart}
      />
    </>
  );
}

export default App;
