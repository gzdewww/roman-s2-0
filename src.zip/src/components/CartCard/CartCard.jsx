import React from "react";

export default function CartCard({ dish, quantity, price }) {
  const { name, image } = dish;

  return (
    <div className="cart-card">
      <img src={image} alt={name} />
      <div className="cart-card-info">
        <h3>{name}</h3>
        <p>Price: {price}</p>
        <p>Quantity: {quantity}</p>
      </div>
    </div>
  );
}
