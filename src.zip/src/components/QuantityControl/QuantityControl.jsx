import { useState } from "react";
import { BsDash, BsPlus } from "react-icons/bs";
import Button from "../../UI/Button/Button";
import "./QuantityControl.scss";

export default function QuantityControl() {
  const [quantity, setQuantity] = useState(1);

  return (
    <div class="quantity">
      <Button
        className="quantity-control"
        onClick={() => setQuantity((prev) => (prev <= 0 ? prev : prev - 1))}
      >
        <BsDash />
      </Button>
      <input class="quantity-value" value={quantity} />
      <Button
        className="quantity-control"
        onClick={() => setQuantity((prev) => prev + 1)}
      >
        <BsPlus />
      </Button>
    </div>
  );
}
