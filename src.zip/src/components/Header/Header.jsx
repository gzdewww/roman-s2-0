import { BsCart } from "react-icons/bs";
import "./Header.scss";
import { BiSolidUserCircle } from "react-icons/bi";
import { useEffect, useState } from "react";
import QuantityControl from "../QuantityControl/QuantityControl";

export default function Header({
  menu,
  cart,
  addToCart,
  removeFromCart,
  clearCart,
}) {
  const [cartExpanded, setCartExpanded] = useState(false);
  const [userExpanded, setUserExpanded] = useState(false);

  const sum = cart.reduce(
    (acc, dish) =>
      acc + menu.find((item) => item.id === dish.id).price * dish.quantity,
    0
  );

  document.addEventListener("click", (event) => {
    if (
      !event.target.closest(".header-cart-content") &&
      cartExpanded &&
      !event.target.closest(".header-cart-button")
    ) {
      setCartExpanded(false);
    }
    if (
      !event.target.closest(".header-user-content") &&
      userExpanded &&
      !event.target.closest(".header-user-button")
    ) {
      setUserExpanded(false);
    }
  });

  return (
    <header>
      <div className="header-wrapper">
        <div className="header-logo">
          <a href="#">
            <img src="/images/logo.svg" alt="Romans's logo" />
          </a>
        </div>
        <ul className="header-menu">
          <li>
            <a href="#">Меню</a>
          </li>
          <li>
            <a href="#">Доставка и оплата</a>
          </li>
          <li>
            <a href="#">Рестораны</a>
          </li>
          <li>
            <a href="#">Справка</a>
          </li>
        </ul>
        <div className="header-cart">
          <div
            className="header-cart-button"
            onClick={() => setCartExpanded(!cartExpanded)}
          >
            <BsCart className="header-cart-logo" />
            <p className="header-cart-sum">
              {`${cart.reduce(
                (acc, dish) =>
                  acc +
                  menu.find((item) => item.id === dish.id).price *
                    dish.quantity,
                0
              )}р.`}
            </p>
          </div>
          <div
            className={`header-cart-content ${cartExpanded ? "expanded" : ""}`}
          >
            <div className="header-cart-content-dishes">
              {cart.map((dish) => {
                return (
                  <div class="header-cart-content-dish">
                    <img class="header-cart-content-dish-photo" src="" alt="" />
                    <div class="header-cart-content-dish-info">
                      <h1>{dish.name}</h1>
                      <QuantityControl />
                      <p class="header-cart-content-dish-info-price">
                        <span class="content-menu-dish-cart-price-value">
                          ${dish.price}
                        </span>{" "}
                        р.
                      </p>
                    </div>
                  </div>
                );
              })}
              <div className="header-cart-content-sum">
                <h1>Итого</h1>
                <p>{}</p>
              </div>
            </div>
            <button id="cart-to-order" className="header-cart-content-button">
              <a href="./src/html/summary.html">Перейти к оформлению</a>
            </button>
          </div>
        </div>
        <div className="header-account">
          <button type="button" onClick={() => setUserExpanded(!userExpanded)}>
            <BiSolidUserCircle className="header-account-logo" />
          </button>

          <div
            className={`header-account-menu ${userExpanded ? "expanded" : ""}`}
          >
            <a id="header-account-menu-cabinet" href="./src/html/cabinet.html">
              <p>Личный кабинет</p>
            </a>
            <a id="header-account-menu-logout" href="#">
              <p>Выход</p>
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
